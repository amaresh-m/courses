# Databricks Certified Data Engineer Professional



<img align="left" role="left" src="https://img-c.udemycdn.com/course/240x135/5125510_214e_3.jpg" width="180" alt="Databricks Certified Data Engineer Professional -Preparation" />
This repository contains the resources of the preparation course for Databricks Data Engineer Professional certification exam on Udemy:
<br/>
<a href="https://www.udemy.com/course/databricks-certified-data-engineer-professional/?referralCode=936CBDC941031CE4D795" target="_blank">https://www.udemy.com/course/databricks-certified-data-engineer-professional/?referralCode=936CBDC941031CE4D795</a>.
<br/>
<br/>


## Practice Exams

<img align="left" role="left" src="https://img-c.udemycdn.com/course/240x135/5317104_98d4.jpg" width="180" alt="Practice Exams: Databricks Data Engineer Professional" />
Practice exams for this certification are available in the following Udemy course:
<br/>
<a href="https://www.udemy.com/course/practice-exams-databricks-data-engineer-professional-k/?referralCode=36812341C732CD1E6D5A" target="_blank">https://www.udemy.com/course/practice-exams-databricks-data-engineer-professional-k/?referralCode=36812341C732CD1E6D5A</a>.<br/>

