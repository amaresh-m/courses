# Databricks notebook source
# MAGIC %run ./Copy-Datasets

# COMMAND ----------

bookstore.clean_up()